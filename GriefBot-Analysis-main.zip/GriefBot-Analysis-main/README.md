# GriefBot-Analysis
It is widely known that while living in the 21st century we are all occupied with some form of machine learning device. We might not be aware of the impact it has and how easy it makes our lives. One form of device is the Chatbot that are used by several companies online to create powerful interactions with their users, to aid business processes by helping different groups of people or individuals to put their inquiries via text or voice. In simple terms, a chatbot is an artificial intelligence program that chats with you. 

The start-up idea that we came up with is called the GriefBot, a commercial chatbot aiming at providing a platform for the people who wish to have a chat conversation with someone who has died or ask any lingering questions. By using advanced artificial intelligence techniques, the GriefBot will be able to learn the tone of the voice of the deceased. It can be used as an isolated chatbot or as a plug-in in your social websites. Analysis has been performed on the provided data to answer the main research question: 
What is the most efficient way to measure the performance of our GriefBot?

